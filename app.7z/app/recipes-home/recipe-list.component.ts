import { Component } from '@angular/core';

@Component({
  templateUrl: 'app/recipes-home/recipe-list.component.html'
})

export class RecipeListComponent {
  
 }