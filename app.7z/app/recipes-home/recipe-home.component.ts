import { Component } from '@angular/core';

@Component({
	templateUrl: 'app/recipes-home/recipe-home.component.html',
	styleUrls: ['app/recipes-home/recipe-home.component.css']
})

export class RecipeComponent {
	
}