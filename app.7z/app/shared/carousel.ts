import {Component} from '@angular/core';
import {Http} from '@angular/http';

@Component({
    selector: "carousel",
    templateUrl: 'app/shared/carousel.html',
		styleUrls: ['app/shared/carousel.css']
})

export class CarouselComponent {
   
}