import { Component } from '@angular/core';

@Component({
	templateUrl: 'app/recipes/desert-recipes.component.html'
})

export class DesertComponent {
	
}