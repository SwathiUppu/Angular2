import { Component } from '@angular/core';

@Component({
	templateUrl: 'app/recipes/entree-recipes.component.html'
})

export class EntreeComponent {
	
}